#pragma once
#include "ResourceScheduler.h"
#include<fstream>

void generator(ResourceScheduler&,int);

void WriteData(string fileName, string text);